#' @title This finds the working directory
#'
#' @description This is where we put more stuff
#'
#' @return working directory
#' @export
#'
#' @examples mygetwd()
mygetwd <- function(){
  getwd()
}

mygetwd()
